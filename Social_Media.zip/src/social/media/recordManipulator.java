package social.media;

public class recordManipulator {
    @Deprecated
    public static String stringify(User record) {
        return record.formatRecord();
    }
}
